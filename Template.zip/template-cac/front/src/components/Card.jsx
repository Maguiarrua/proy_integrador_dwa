// Aquí debes utilizar la información que llega por props al componente.
// Puede hacer destructuring de las propidades del objeto props si quieres

const Card = (props) => {
  return (
    <div>
      {/* <button onClick={}>X</button>
          <h2></h2>
          <h2></h2>
          <h2></h2>
          <h2></h2>
          <h2></h2>
          <img src={} alt='' /> */}
    </div>
  );
};

export default Card;
