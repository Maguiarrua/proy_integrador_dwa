import Card from "./Card";

const Cards = (props) => {
  return (
    <>
      <div></div>
    </>
  );
};

export default Cards;
